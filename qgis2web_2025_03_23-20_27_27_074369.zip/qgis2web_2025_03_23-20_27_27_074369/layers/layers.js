var wms_layers = [];



var layersList = [];
